package kr.abilitysurvival;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class AbilitySurvival implements ModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, String>>() {}.getType();
    private static final Map<UUID, String> ABILITIES = new ConcurrentHashMap<>();
    private static final Set<UUID> RESPAWN_GEAR = ConcurrentHashMap.newKeySet();
    private static MinecraftServer server;
    private static Path saveFile;
    private static long ticks;

    private static final List<String> NAMES = List.of("헐크", "도굴꾼", "닌자", "싸움꾼", "재생술사", "맷집돼지", "광폭자", "파푸의 신", "맞는건싫어요", "권력자");
    private static final Map<String, String> DESCRIPTIONS = Map.ofEntries(
        Map.entry("헐크", "힘 II, 최대 체력 절반"),
        Map.entry("도굴꾼", "효율 VII·행운 III·내구성 III 곡괭이. 사망 시 재지급"),
        Map.entry("닌자", "신속 I, 힘 I. /포션으로 투명화 포션 획득"),
        Map.entry("싸움꾼", "힘 I"),
        Map.entry("재생술사", "재생 I, 나약함 I"),
        Map.entry("맷집돼지", "저항 II, 재생 I, 나약함 II"),
        Map.entry("광폭자", "날카로움 VI 네더라이트 검(소실의 저주). 사망 시 재지급, 나약함 II, 느린 낙하"),
        Map.entry("파푸의 신", "힘 I, 신속 I, 최대 체력 5. 재생 효과 없음. 다이아몬드 갑옷 착용 가능"),
        Map.entry("맞는건싫어요", "재생 I, 저항 III, 나약함 I"),
        Map.entry("권력자", "네더라이트 갑옷·검·곡괭이 지급, 나약함 II")
    );

    @Override public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        ServerLifecycleEvents.SERVER_STARTED.register(s -> { server = s; saveFile = s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("ability-survival.json"); load(); });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> applyAll(handler.player));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            applyAll(newPlayer);
            if (RESPAWN_GEAR.remove(newPlayer.getUUID())) giveDeathGear(newPlayer);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer p) {
                String a = ABILITIES.get(p.getUUID());
                if ("도굴꾼".equals(a) || "광폭자".equals(a)) RESPAWN_GEAR.add(p.getUUID());
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (++ticks % 20 == 0) for (ServerPlayer p : s.getPlayerList().getPlayers()) applyAll(p);
            if (ticks % 600 == 0) save();
        });
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("능력뽑기").requires(src -> src.hasPermission(2)).executes(ctx -> {
            List<ServerPlayer> players = new ArrayList<>(ctx.getSource().getServer().getPlayerList().getPlayers());
            Collections.shuffle(players);
            ABILITIES.clear();
            int n = Math.min(players.size(), NAMES.size());
            for (int i = 0; i < n; i++) {
                ServerPlayer p = players.get(i);
                String ability = NAMES.get(i);
                ABILITIES.put(p.getUUID(), ability);
                clearKnownEffects(p);
                resetMaxHealth(p);
                giveStartingGear(p, ability);
                applyAll(p);
                p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§a[능력] 당신의 능력은 §e" + ability + "§a입니다!"));
            }
            for (int i = n; i < players.size(); i++) players.get(i).sendSystemMessage(net.minecraft.network.chat.Component.literal("§c[능력] 10명 제한으로 이번 능력이 배정되지 않았습니다."));
            ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("능력 배정 완료: " + n + "명 / 최대 10명"), true);
            save(); return 1;
        })));
        d.register(Commands.literal("능력").executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            String a = ABILITIES.get(p.getUUID());
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(a == null ? "§c배정된 능력이 없습니다." : "§e[능력] " + a + "§f: " + DESCRIPTIONS.get(a)));
            return 1;
        }));
        d.register(Commands.literal("포션").executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            if (!"닌자".equals(ABILITIES.get(p.getUUID()))) { p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§c닌자만 사용할 수 있습니다.")); return 0; }
            run(p, "give " + target(p) + " minecraft:potion[minecraft:potion_contents={potion:\"minecraft:invisibility\"}] 1");
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§a투명화 포션을 지급했습니다. (3분)")); return 1;
        }));
        d.register(Commands.literal("서바이벌종료").requires(src -> src.hasPermission(2)).executes(ctx -> {
            for (ServerPlayer p : ctx.getSource().getServer().getPlayerList().getPlayers()) {
                clearKnownEffects(p); resetMaxHealth(p);
                for (EquipmentSlot slot : List.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET)) p.setItemSlot(slot, ItemStack.EMPTY);
                p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§c[서바이벌] 능력 서바이벌이 종료되었습니다."));
            }
            ABILITIES.clear(); RESPAWN_GEAR.clear(); save();
            ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("모든 능력 배정을 초기화했습니다."), true); return 1;
        }));
    }

    private static String target(ServerPlayer p) { return "@a[name=\"" + p.getGameProfile().getName().replace("\"", "") + "\"]"; }
    private static void run(ServerPlayer p, String command) {
        p.getServer().getCommands().performPrefixedCommand(p.getServer().createCommandSourceStack().withPermission(4), command);
    }
    private static void clearKnownEffects(ServerPlayer p) {
        run(p, "effect clear " + target(p) + " minecraft:strength");
        run(p, "effect clear " + target(p) + " minecraft:speed");
        run(p, "effect clear " + target(p) + " minecraft:regeneration");
        run(p, "effect clear " + target(p) + " minecraft:weakness");
        run(p, "effect clear " + target(p) + " minecraft:resistance");
        run(p, "effect clear " + target(p) + " minecraft:slow_falling");
    }
    private static void effect(ServerPlayer p, String id, int amp) { run(p, "effect give " + target(p) + " minecraft:" + id + " 30 " + amp + " true"); }
    private static void resetMaxHealth(ServerPlayer p) { run(p, "attribute " + target(p) + " minecraft:generic.max_health base set 20"); }
    private static void applyAll(ServerPlayer p) {
        String a = ABILITIES.get(p.getUUID()); if (a == null || p.isDeadOrDying()) return;
        clearKnownEffects(p);
        switch (a) {
            case "헐크" -> { effect(p,"strength",1); halfHealth(p); }
            case "도굴꾼" -> {}
            case "닌자" -> { effect(p,"speed",0); effect(p,"strength",0); }
            case "싸움꾼" -> effect(p,"strength",0);
            case "재생술사" -> { effect(p,"regeneration",0); effect(p,"weakness",0); }
            case "맷집돼지" -> { effect(p,"resistance",1); effect(p,"regeneration",0); effect(p,"weakness",1); }
            case "광폭자" -> { effect(p,"weakness",1); effect(p,"slow_falling",0); }
            case "파푸의 신" -> { effect(p,"strength",0); effect(p,"speed",0); fiveHealth(p); }
            case "맞는건싫어요" -> { effect(p,"regeneration",0); effect(p,"resistance",2); effect(p,"weakness",0); }
            case "권력자" -> effect(p,"weakness",1);
        }
        if (!"헐크".equals(a) && !"파푸의 신".equals(a)) resetMaxHealth(p);
    }
    private static void halfHealth(ServerPlayer p) { run(p, "attribute " + target(p) + " minecraft:generic.max_health base set 10"); if (p.getHealth() > 10) p.setHealth(10); }
    private static void fiveHealth(ServerPlayer p) { run(p, "attribute " + target(p) + " minecraft:generic.max_health base set 5"); if (p.getHealth() > 5) p.setHealth(5); }
    private static void giveStartingGear(ServerPlayer p, String a) {
        switch (a) {
            case "도굴꾼" -> give(p, "minecraft:diamond_pickaxe[minecraft:enchantments={efficiency:7,fortune:3,unbreaking:3}]");
            case "광폭자" -> give(p, "minecraft:netherite_sword[minecraft:enchantments={sharpness:6,vanishing_curse:1}]");
            case "권력자" -> {
                equip(p,"head","netherite_helmet"); equip(p,"chest","netherite_chestplate"); equip(p,"legs","netherite_leggings"); equip(p,"feet","netherite_boots");
                give(p,"minecraft:netherite_sword"); give(p,"minecraft:netherite_pickaxe");
            }
        }
    }
    private static void giveDeathGear(ServerPlayer p) {
        String a = ABILITIES.get(p.getUUID());
        if ("도굴꾼".equals(a)) give(p,"minecraft:diamond_pickaxe[minecraft:enchantments={efficiency:7,fortune:3,unbreaking:3}]");
        if ("광폭자".equals(a)) give(p,"minecraft:netherite_sword[minecraft:enchantments={sharpness:6,vanishing_curse:1}]");
    }
    private static void give(ServerPlayer p, String item) { run(p,"give " + target(p) + " " + item + " 1"); }
    private static void equip(ServerPlayer p, String slot, String item) { run(p,"item replace entity " + target(p) + " armor." + slot + " with minecraft:" + item); }
    private static void load() {
        try { if (Files.exists(saveFile)) { Map<String,String> raw = GSON.fromJson(Files.readString(saveFile), MAP_TYPE); if (raw != null) raw.forEach((k,v) -> { try { if (NAMES.contains(v)) ABILITIES.put(UUID.fromString(k),v); } catch (IllegalArgumentException ignored) {} }); } }
        catch (IOException e) { System.err.println("[AbilitySurvival] load failed: " + e.getMessage()); }
    }
    private static void save() {
        if (saveFile == null) return;
        Map<String,String> raw = new HashMap<>(); ABILITIES.forEach((k,v) -> raw.put(k.toString(),v));
        try { Files.createDirectories(saveFile.getParent()); Files.writeString(saveFile,GSON.toJson(raw)); }
        catch (IOException e) { System.err.println("[AbilitySurvival] save failed: " + e.getMessage()); }
    }
}
